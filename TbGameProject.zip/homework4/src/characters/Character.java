package characters;

import opponents.Opponent;
import weapons.Weapon;

public interface Character<W> {

	
	public int punch() throws InsufficientStaminaException;
	public int attackWithWeapon(int attackType, W weapon)throws InsufficientStaminaException;
	public void guard();
	public void run() throws CharacterRunsException;
	public abstract int specialAction() throws SpecialAlreadyUsedException;
}
