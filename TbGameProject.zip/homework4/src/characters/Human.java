package characters;
import weapons.*;
import opponents.Opponent;
import weapons.*;
import TBgame.*;
public abstract class Human<W extends Weapon> implements Character<W>,Turn {

	private W weapon;
	private String name;
	private int points, attack, speed, stamina;
	private double reducingDamageP;
	private int specialActionCounter;

	public Human(String name) {
		this.name = name;
		initializeHuman();
		
	}

	private void initializeHuman() {
		// gives values between (100, 150)
		this.points = ((int)Math.round(Math.random()*50))+100;
		// gives values between (20, 40)
		this.attack = ((int)Math.round(Math.random()*20))+20;
		// gives values between (10, 99)
		this.speed = ((int)Math.round(Math.random()*89))+10;
		setWeapon();
		this.stamina = 10;
		this.reducingDamageP = 1;
		this.specialActionCounter = 0;
		
	}

	@SuppressWarnings("unchecked")
	private void setWeapon() {
		int rand = (int)Math.floor(Math.random()*3)+1;
		if(rand == 0) {
			weapon = (W) new Sword();
		}else if(rand == 1)
			weapon = (W) new Spear();
		else
			weapon = (W) new Bow();
			
	}
	public boolean isAlive() {
		return this.points > 0;
	}
	
	public void getDamage(int dealedDamage) {
		int damage = (int) (dealedDamage*reducingDamageP);
		this.points -= damage;
		reducingDamageP = 1;
	}
	
	@Override
	public int punch() throws InsufficientStaminaException{
		decreaseStamina(2);
		return (int)Math.round(getAttack()*0.8);
	}

	@Override
	public int attackWithWeapon(int weaponAttackType, W weapon) throws InsufficientStaminaException{
		int damage = 0;
		 if(weapon instanceof Sword|| weapon instanceof Spear) {
			 Weapon newWeapon = (Weapon) weapon;
			 if(stamina-2<0) 
					throw new InsufficientStaminaException();
			 switch(weaponAttackType) {
	          case 1:
	        	  decreaseStamina(2);
	        	  damage = newWeapon.firstAttack(getAttack());
	        	  break;
	          case 2:
	        	  decreaseStamina(2);
	        	  damage = newWeapon.secondAttack(getAttack());
	        	  break;
	        }
		 }
		 else if (weapon instanceof Bow) {
			 Weapon newWeapon = (Weapon) weapon;
			 switch(weaponAttackType) {
	          case 1:
	        	  decreaseStamina(1);
	        	  damage = newWeapon.firstAttack(getAttack());
	        	  break;
	          case 2:
	        	  decreaseStamina(3);
	        	  damage = newWeapon.secondAttack(getAttack());
	        	  break;
	        }
		 }
		 return damage;
		
	}
	@Override
	public void guard() {
		stamina += 3;
		reducingDamageP = 0.25;
	}
	public int getPoints() {
		return points;
	}
	@Override
	public void run() throws CharacterRunsException {
		throw new CharacterRunsException();
		
	}
	
	@Override
	public abstract int specialAction() throws SpecialAlreadyUsedException;
	
	public W getWeapon() {
		return weapon;
	}
	public int getStamina() {
		return stamina;
	}
	public abstract String getName();

	public int getSpeed() {
		return speed;
	}
	public String getOwner() {
		return name;
	}
	public int getSpecialActionCounter() {
		return specialActionCounter;
	}

	public int getAttack() {
		return attack;
	}
	public void incrementSpecialActionCounter() {
		specialActionCounter++;
	}
	public abstract boolean isSpecial();
	void increaseStamina(int increase) {
		stamina = stamina + increase;
	}
	private void decreaseStamina(int decrease) throws InsufficientStaminaException{
		if(stamina>decrease) 
			stamina = stamina - decrease;
		else {
			throw new InsufficientStaminaException();
		}
	}
	

}
