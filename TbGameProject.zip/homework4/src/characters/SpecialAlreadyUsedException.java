package characters;

public class SpecialAlreadyUsedException extends Exception {

	
	public SpecialAlreadyUsedException() {
		super("Special has already been used!");
	}
}
