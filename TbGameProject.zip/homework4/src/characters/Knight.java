package characters;


public class Knight extends Human {
	private boolean isSpecial;
	public Knight(String name) {	
		super(name);
		isSpecial = false;
	}
	
	@Override
	public int specialAction() throws SpecialAlreadyUsedException {
		if(getSpecialActionCounter()>0)
			throw new SpecialAlreadyUsedException();
		incrementSpecialActionCounter();
		isSpecial = true;
		return 0;
	}
	public String getName() {
		return "Knight";
	}
	public boolean isSpecial() {
		return isSpecial;
	}
	public double attackModifier() {
		isSpecial = false;
		return 3;
	}
	

}
