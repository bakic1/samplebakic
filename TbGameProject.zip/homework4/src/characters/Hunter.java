package characters;

public class Hunter extends Human{
	private boolean isSpecial;
	private int specialCounter;
	public Hunter(String name) {
		super(name);
		isSpecial = false;
		specialCounter = 0;
	}

	@Override
	public int specialAction() throws SpecialAlreadyUsedException {
		if(getSpecialActionCounter()>0)
			throw new SpecialAlreadyUsedException();
		incrementSpecialActionCounter();
		isSpecial = true;
		return (int)Math.round(getAttack()*0.5);
	}
	public String getName() {
		return "Hunter";
	}

	@Override
	public double attackModifier() {
		isSpecial = false;
		return 0.5;//this is not nesessery
	}
	public boolean isSpecial() {
		return isSpecial;
	}

}
