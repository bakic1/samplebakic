package characters;

public class InsufficientStaminaException extends Exception{
	public InsufficientStaminaException() {
		super("InsufficientStaminaException");
	}
}
