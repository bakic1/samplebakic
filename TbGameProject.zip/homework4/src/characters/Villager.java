package characters;

public class Villager extends Human{

	public Villager(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int specialAction() throws SpecialAlreadyUsedException {
		System.out.println("has no special for villager");
		return 0;
	}
	public String getName() {
		return "Villager";
	}

	@Override
	public double attackModifier() {
		return 0;
	}

	@Override
	public boolean isSpecial() {
		return false;
	}
}
