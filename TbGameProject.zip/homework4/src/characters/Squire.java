package characters;

public class Squire extends Human{
	private boolean isSpecial;

	public Squire(String name) {
		super(name);
		isSpecial = false;
	}

	@Override
	public int specialAction() throws SpecialAlreadyUsedException {
		if(getSpecialActionCounter()>0)
			throw new SpecialAlreadyUsedException();
		increaseStamina(10);
		incrementSpecialActionCounter();
		return (int)Math.round(getAttack()/2);
	}
	public String getName() {
		return "Squire";
	}

	@Override
	public double attackModifier() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isSpecial() {
		return isSpecial;
	}

}
