package TBgame;

import characters.CharacterRunsException;
import characters.InsufficientStaminaException;
import characters.SpecialAlreadyUsedException;
import java.util.*;
public class main {

	public static void main(String[] args) throws InsufficientStaminaException, CharacterRunsException, SpecialAlreadyUsedException {

		TBGame tbgame = new TBGame();
		
		tbgame.start();
	
		
	}

}
