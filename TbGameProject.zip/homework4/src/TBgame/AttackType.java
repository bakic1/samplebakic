package TBgame;

public enum AttackType {
	Punch, AttackWithWeapon,Guard,SpecialAction,Run,;
	
	
		
	
}
