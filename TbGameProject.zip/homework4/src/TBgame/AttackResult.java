package TBgame;

import opponents.*;

public class AttackResult<T>{
	private int damage;
	private T attackType;
	private String CharacterName;
	private Opponent attackedOpponent;
	public AttackResult(int damage) {
		this.damage = damage;
		
	}
	public int getDamage() {
		return damage;
	}
	public T getAttackType() {
		return attackType;
	}
	public String getCharacterName() {
		return CharacterName;
		
	}
	public Opponent getAttackedOpponent() {
		return attackedOpponent;
	}
	public void setCharacterType(String CharacterName) {
		this.CharacterName = CharacterName;
	}
	public void setAttackType( T attackType) {
		this.attackType = attackType;
	}
	public void setOpponent(Opponent attackedOpponent) {
		this.attackedOpponent = attackedOpponent;
		
	}

}
