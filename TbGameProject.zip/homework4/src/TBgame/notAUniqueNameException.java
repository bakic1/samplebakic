package TBgame;

public class notAUniqueNameException extends Exception{
	public  notAUniqueNameException() {
		super("names cannot be same ");
	}

}
