package TBgame;
import java.util.*;
import opponents.*;
import weapons.*;
import characters.*;

import java.util.Random;
import java.util.Scanner;

public class TBGame {
	private Queue<Turn> turnOrder;
	private List<Turn> items;
	private List <Human<Weapon>> selectedCharacters;
	private List<Opponent> opponents;
	private Menu menu;
	private int choiceOpponentId;
	private Scanner keyboard;
	public TBGame() {
		turnOrder = new LinkedList<>();
	}
	public void start() {
		new Initilalizer().takeInputsAndMaketurnOrder();
		menu = new Menu();
		menu.turnOrderStats();
		Move move = new Move();
		move.battleStarting();
	}
	public int takeInputsChecking(int number) {
		keyboard = new Scanner(System.in);
		while(true){
			try {
				int choice = keyboard.nextInt();
				if(choice>0 && choice<=number)return choice;
				else {
					System.out.println("enter valid number: ");
				}
			} catch (Exception e) {
				keyboard.nextLine();
				System.out.println("invalid input try again: ");
			}
		}
		
	}	
	private class Initilalizer{
		
		public void takeInputsAndMaketurnOrder() {
			System.out.println("welcome to TBGame\n\n");
			selectingCharacters();
			createQueue();
		}
		public void randomOpponentsMaker() {
			Random random = new Random();
			int randomOpponentId;
			opponents = new ArrayList<>();
			for(int i = 0; i<random.nextInt(1,5);i++) {
				randomOpponentId = random.nextInt(1,5);
				switch (randomOpponentId) {
				case 1:
					opponents.add(new Slime(i+1));
					break;
				case 2:
					opponents.add(new Wolf(i+1));
					break;
				case 3:
					opponents.add(new Orc(i+1));
					break;

				case 4:
					opponents.add(new Goblin(i+1));

					break;
				default:
					break;
				}
			}
		}
		public void createQueue() {
			items = new ArrayList<>();
			randomOpponentsMaker();
			items.addAll(opponents);
			items.addAll(selectedCharacters);
			Collections.sort(items, Comparator.comparingInt(Turn::getSpeed).reversed());
			//^^^ this code for sorting opponents and characters according to their speed.
			turnOrder.addAll(items);
		}
		
		public Human<Weapon> selectCharacter(String name) {
			int random = new Random().nextInt(4);
			switch(random) {
				case 0:
					return new Hunter(name);
				case 1:
					return new Knight(name);
				case 2:
					return new Squire(name);
				default:
					return new Villager(name);			
			}
		}
		
		private void selectingCharacters() {
			selectedCharacters = new ArrayList <Human<Weapon>>();//initilaize for characters array list
			System.out.println("Please enter the number of characters to create(1 2 or 3): ");
			int characterCount = 0;
			characterCount = takeInputsChecking(3);	
			ArrayList<String> name = new ArrayList<>();	
			for(int i = 0; i<characterCount;i++) {
				System.out.println("Enter name for your "+(i+1)+". character: ");
				String inputName = keyboard.next();
				while(true) {//checking names are same or not 
					try {
						if(name.contains(inputName)) 
							throw new notAUniqueNameException();						
						else 
							break;				
					} catch (notAUniqueNameException e) {
						System.out.println(e.getMessage());
						inputName = keyboard.next();
					}
				}
				name.add(inputName);
				selectedCharacters.add(selectCharacter(name.get(i)));//we are making new characters array list
			}
		}		
	}
	private class Menu {
		private Scanner keyboard;
		public Menu() {
				keyboard = new Scanner(System.in);
				startingOpponents();
				charactersStats();
			}
		
		public int humanMoveMenu() {
			
			System.out.println("[1] Punch");
			System.out.println("[2] Attack with weapon");
			System.out.println("[3] Guard");
			System.out.println("[4] Special Action");
			System.out.println("[5] Run");
			System.out.println("please select an option: ");
			return takeInputsChecking(5);
			
		}
		
		public void startingOpponents() {
			System.out.println("These opponent appeared in front of you: ");			
			for (Turn turn : opponents) {
				System.out.println("Id: "+turn.getOwner()+", Type: "+turn.toString()+", Points: "+turn.getPoints()+
						", Attack: "+turn.getAttack()+", Speed: "+turn.getSpeed());
			
			}
		}
		public void turnOrderStats() {
			System.out.print("*** Turn Order: ");
			for (Turn turn : turnOrder) {
				System.out.print(turn.getOwner()+" ");
			}
			System.out.print("***\n");
		}
		public void charactersStats() {
			int count = 1;
			for (Human<Weapon> chr : selectedCharacters) {
				System.out.println("The stats of your "+count+". character: ");
				System.out.println(chr.getOwner()+", Job: "+chr.getName()+" Stamina: "+chr.getStamina()+
						" Points: "+chr.getPoints()+" Attack: "+chr.getAttack()+" Speed: "+chr.getSpeed()+
						" Weapon: "+chr.getWeapon().toString()+" with +"+ chr.getWeapon().getAdditionalAttack()+" attack\n");
				count++;
			}
		}
	}
	private class Move{
		public void battleStarting(){
			System.out.println("The battle starts!\n");
			menu.turnOrderStats();
			int moveCounter = 1;
		
				while(!opponents.isEmpty()) {
					Turn turn = turnOrder.poll();
					if(isHuman(turn)) {
						Human<Weapon> turnHuman = (Human<Weapon>) turn;	
						AttackResult<AttackType> attackResult1;		
						attackResult1 = moveCharacter(turnHuman);
						System.out.println("Move "+moveCounter+": "+turn.getOwner()+" "+attackResult1.getAttackType()+" "+//this one for move information
								"opponent "+choiceOpponentId+" Deals "+attackResult1.getDamage()+" damage");
						System.out.println(turnHuman.getOwner()+", Job: "+turnHuman.getName()+", Points: "+turnHuman.getPoints()+//this one for characters last sitiuation
								", Stamina: "+turnHuman.getStamina());
						System.out.println("opponent "+choiceOpponentId+" Type: "+attackResult1.getAttackedOpponent().toString()+" Points: "+
								attackResult1.getAttackedOpponent().getPoints());// this one for opponent who attacked information
						moveCounter++;	

					}
					else if(isOpponent(turn)){
						Opponent turnOpponent = (Opponent) turn;			
						AttackResult<Action> attackResult2 = moveOpponent(turnOpponent);
						System.out.println("Move "+moveCounter+": "+turn.getOwner()+" "+attackResult2.getAttackType()+" to "+
						attackResult2.getCharacterName()+" Deals "+attackResult2.getDamage()+" damage");
						moveCounter++;		
					}
					turnOrder.offer(turn);
					System.out.println();
					removeDeaths();
					checkGameContinue();
					menu.turnOrderStats();
				}
		}
		public void removeDeaths() {
			Turn removeTurn = null;
			for (Turn turn : turnOrder) {
				if(!turn.isAlive()) {
					System.out.println(turn.getOwner()+" is death");
					removeTurn = turn;
				}	
			}
			if(removeTurn == null) return;
			if(isHuman(removeTurn)) {
				selectedCharacters.remove(removeTurn);
			}
			else if (isOpponent(removeTurn)) {
				opponents.remove(removeTurn);
			}
			turnOrder.remove(removeTurn);
			
			
		}
		public void checkGameContinue() {
			if(selectedCharacters.isEmpty()) {
				System.out.println("all of your characters are death you lost!");
				System.exit(0);
			}
			else if(opponents.isEmpty()) {
				System.out.println("all of opponents are death you win!");
				System.exit(0);
			}
		}
		
		public boolean isHuman(Turn who) {
			return(who instanceof Human);
		}
		public boolean isOpponent(Turn who) {
			return(who instanceof Opponent);
		}
		public AttackResult<AttackType> moveCharacter(Human<Weapon> human)
		 {
			double attackModifier = 1;
			int choiceAttackType = 0;
			AttackResult<AttackType> attackResult = null;
		    AttackType attackType = null;
		    int damage = 0;
				if(human.isSpecial()) {//isSpecial for after the Special using
					if(human instanceof Knight)attackModifier = human.attackModifier();
					else if(human instanceof Hunter ) {//
						human.attackModifier();// this is just for no more isSpecial
						moveCharacter(human);
					}
				}
				while(true) {
					try {
						choiceAttackType = menu.humanMoveMenu();
						System.out.println("Please enter an opponent id: ");
						choiceOpponentId = opponentExistingChecking().getOpponentId();
						if(choiceAttackType == 1) {
							damage = (int)Math.round(human.punch()*attackModifier);
							attackResult = damageChosenOpponent(choiceOpponentId, damage);
							attackType =  AttackType.Punch;
							attackResult.setAttackType(attackType);
						}
						else if(choiceAttackType == 2) {
							System.out.println("Please select weapon attack type "
									+human.getWeapon().getAttackTypeName()+ ": ");
							int weaponAttackType = takeInputsChecking(2);
							damage = (int)Math.round(attackModifier*human.attackWithWeapon(weaponAttackType, human.getWeapon()));
							attackResult = damageChosenOpponent(choiceOpponentId,damage);
							attackType = AttackType.AttackWithWeapon;
							attackResult.setAttackType(attackType);
						}
						else if(choiceAttackType == 3) {
							human.guard();
							attackType = AttackType.Guard;
							attackResult = damageChosenOpponent(choiceOpponentId,0);
							attackResult.setAttackType(attackType);
						}
						else if(choiceAttackType == 4) {
							damage = (int)Math.round(human.specialAction()*attackModifier);
							attackResult = damageChosenOpponent(choiceOpponentId,damage);
							attackType = AttackType.SpecialAction;
							attackResult.setAttackType(attackType);
						}
						else {
							try {
								human.run();
							} catch (CharacterRunsException e) {
								System.out.println(e.toString());
								System.exit(0);
							}
							
							
						}
						break;
					} catch (Exception e) {
						System.out.println(e.toString());
					}
					
				}
				
				return attackResult;
		}
		public AttackResult<AttackType> damageChosenOpponent(int choiceOpponentId,int dealedDamage) {
			int takenDamage;
			for (Opponent opnt : opponents) {
				if (opnt.getOpponentId() == choiceOpponentId) {
					takenDamage = opnt.getDamage(dealedDamage);
					AttackResult <AttackType> attackResult = new AttackResult<>(takenDamage);
					attackResult.setOpponent(opnt);
					return attackResult;
				}
			}
			return null;
		
		}	
		public AttackResult<Action> moveOpponent(Opponent opponent) {
			Random random = new Random();
			int randomChoice = random.nextInt(selectedCharacters.size());
			Human<Weapon> chosenHuman = selectedCharacters.get(randomChoice);
			AttackResult<Action> attackResult = opponent.action(chosenHuman);
			attackResult.setCharacterType(chosenHuman.getOwner());
				if(opponent instanceof Wolf) {
					if(attackResult.getAttackType() == Action.SPECIAL) {
						Wolf cloneWolf = ((Wolf) opponent).clone(maksOpponentID()+1);
						if(!(cloneWolf == null)) { 
							AttackResult<Action> wolfAttack = moveOpponent(cloneWolf);
							System.out.println("Move for new Wolf "+": "+cloneWolf.getOwner()+" "+wolfAttack.getAttackType()+" to "+
									wolfAttack.getCharacterName()+" Deals "+wolfAttack.getDamage()+" damage");
							opponents.add(cloneWolf);
							turnOrder.offer(cloneWolf);
						}
					}
				}
			return attackResult;
		}
		public int maksOpponentID() {
			int maksId = 0;
			for (Opponent opn : opponents) {
				if(opn.getOpponentId()>maksId) {
					maksId = opn.getOpponentId();
				}
			}
			return maksId;
		}
		public Opponent opponentExistingChecking() {
			Scanner keyboard = new Scanner(System.in);
			while(true){
				try {
					int choice = keyboard.nextInt();
					for (Opponent opponent : opponents) {
						if(opponent.getOpponentId()==choice) {
							return opponent;
						}
					}	
					System.out.println("there is no such opponent in the turn order try again ");
				} catch (Exception e) {
					keyboard.nextLine();
					System.out.println("invalid input try again: ");
				}
			}
		}
	}
}

