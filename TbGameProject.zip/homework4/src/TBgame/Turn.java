package TBgame;

public interface Turn {
	String getOwner();
	int getSpeed();
	int getPoints();
	int getAttack();
	double attackModifier();
	boolean isAlive();
}
