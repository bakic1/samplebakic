package opponents;

import characters.Human;
import weapons.Weapon;

public class Orc extends Opponent {

	public Orc(int id) {
		super(id);
	}

	@Override
	public int special(Human<Weapon> human) {
		return attack(getAttack()*2,human);
	}

	@Override
	protected int actionAfterSpecial(Human<Weapon> human) {
		return 0;
	}
	public String toString() {
		return "Orc";
	}

	@Override
	public double attackModifier() {
		// TODO Auto-generated method stub
		return 0;
	}
}
