package opponents;
import characters.Human;
import weapons.Weapon;

public class Wolf extends Opponent{
	
	public Wolf(int id) {
		super(id);
	}
	public Wolf(int id, int points,int attack,int speed) {
		super(id,points,attack,speed);
	}
	public Wolf clone(int id) {
		if(Math.random()<=0.2) {
			System.out.println("new wolf apperead");
		return new Wolf(id,this.getPoints(),this.getAttack(),this.getSpeed());}
		else return null;
	}

	@Override
	public int special(Human<Weapon> human) {
		
			increaseOpponentCount();
				
		return 0;
	}

	@Override
	protected int actionAfterSpecial(Human<Weapon> human) {
		return action(human).getDamage();
	}
	public String toString() {
		return "wolf";
	}
	@Override
	public double attackModifier() {
		// TODO Auto-generated method stub
		return 0;
	}
}
