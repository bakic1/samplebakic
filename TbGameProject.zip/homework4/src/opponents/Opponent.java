package opponents;
import TBgame.*;
import characters.*;
import weapons.*;
public abstract class Opponent implements Turn{
	
	private int opponentId;
	private int points, attack, speed;
	private Action currentAction;
	private int guarding;
	private int opponentCount;
	
	public Opponent(int id) {
		this.opponentId = id;
		guarding = 1;
		opponentCount = 4;
		initializeOpponent();
		currentAction = null;
		
	}
	private void initializeOpponent() {
		// gives values between (50, 150)
		
		this.points = ((int)Math.round(Math.random()*100))+50;
		// gives values between (5, 25)
		this.attack = ((int)Math.round(Math.random()*20))+5;
		// gives values between (1, 90)
		this.speed = ((int)Math.round(Math.random()*89))+1;
	}
	public Opponent(int id, int points,int attack,int speed) {//this one for cloning
		this.opponentId = id;
		this.points = points;
		this.attack = attack;
		this.speed = speed;
		guarding = 1;
		
	
	}
	
	public int getOpponentCount() {
		return opponentCount;
	}
	public int getOpponentId() {
		return opponentId;
	}

	public int getPoints() {
		return points;
	}

	public int getAttack() {
		return attack;
	}

	public int getSpeed() {
		return speed;
	}
	public void increaseOpponentCount() {
		opponentCount++;
	}
	public String getOwner() {
		return ("opponent"+opponentId);
	}

	
	public void setAction() {		
		if(currentAction == Action.SPECIAL) {
			this.currentAction = Action.AFTERSPECIAL;
			return;
		}
		int rand = (int)Math.floor(Math.random()*3);
		switch(rand) {
			case 0:
				this.currentAction = Action.ATTACK;
				break;
			case 1:
				this.currentAction = Action.SPECIAL;
				break;
			default:
				this.currentAction = Action.GUARD;
		}
	}
	
	public int getDamage(int dealedDamage) {
		int damageTaken = (int)Math.round(dealedDamage/guarding);
		this.points -= (int)Math.round(dealedDamage/guarding);
		guarding = 1;
		if(points<=0) {
			opponentCount--;
		}
		return damageTaken;
	}
	
	void setPoints(int points) {
		if(points > 150)
			this.points = 150;
		else
			this.points = points;
	}
	
	public boolean isAlive() {
		return this.points > 0;
	}
	public AttackResult<Action> action(Human<Weapon> human) {
		setAction();
		int damage = 0;
		switch(currentAction) {
		case ATTACK:			
			damage = attack(attack, human);
			break;
		case GUARD:
			guard();
			break;
		case SPECIAL:
			damage = special(human);
			break;
		default:
			damage = actionAfterSpecial(human);
			break;
		}
		AttackResult<Action> attackResult= new AttackResult<>(damage);
		attackResult.setAttackType(currentAction);
		return attackResult;
	}
	public int attack(int damage, Human<Weapon> human) {
		human.getDamage(attack);
		return attack;
	}
	
	public void guard() {
		guarding = 2;
	}
	public abstract int special(Human<Weapon> human);
	protected abstract int actionAfterSpecial(Human<Weapon> human);
	
}
