package opponents;

import characters.Human;
import weapons.Weapon;

public class Slime extends Opponent {
	
	public Slime(int id) {
		super(id);		
	}

	@Override
	public int special(Human<Weapon> human) {
		int point =  attack(getAttack(),human);
		setPoints(point+getPoints());
		return point;
	}

	@Override
	protected int actionAfterSpecial(Human<Weapon> human) {
		return action(human).getDamage();
		
	}
	public String toString() {
		return "Slime";
	}

	@Override
	public double attackModifier() {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
