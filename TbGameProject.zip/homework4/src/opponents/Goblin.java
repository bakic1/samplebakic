package opponents;

import characters.Human;
import weapons.Weapon;

public class Goblin extends Opponent {

	public Goblin(int id) {
		super(id);
		
	}

	@Override
	public int special(Human<Weapon> human) {
		return super.attack((int) (getAttack()*0.7),human);
		
	}

	@Override
	protected int actionAfterSpecial(Human<Weapon> human) {
		return attack((int) (getAttack()*0.7),human);
	}
	public String toString() {
		return "Goblin";
	}

	@Override
	public double attackModifier() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
