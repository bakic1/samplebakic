package opponents;

public enum Action {
	ATTACK, GUARD, SPECIAL, AFTERSPECIAL;
}
