package weapons;

public class Sword extends Weapon{

	
	public int firstAttack(int attack) {
		int combinedDamage = attack+getAdditionalAttack();
		return combinedDamage;
	}
	
	public int secondAttack(int attack) {
		int totalDamage;
		if(Math.random() <= 0.75) {
			int combinedDamage = attack+getAdditionalAttack();
			totalDamage = combinedDamage*2;
			
		}else
			totalDamage = 0;
		return totalDamage;
	}
	public String toString() {
		return "Sword";
	}

	@Override
	public String getAttackTypeName() {
		return ("([1] Slash [2] Stab");
	}
}