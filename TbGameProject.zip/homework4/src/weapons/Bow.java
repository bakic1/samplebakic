package weapons;

import opponents.Opponent;

public class Bow extends Weapon {

	
	public int firstAttack(int attack) {
		int combinedDamage = attack+getAdditionalAttack();
		int totalDamage = (int)Math.round(combinedDamage*0.8);
		return totalDamage;
	}
	
	public int secondAttack(int attack) {
		int combinedDamage = attack+getAdditionalAttack();
		int totalDamage = (int)Math.round(combinedDamage*2.5);
		return totalDamage;
	}
	public String toString() {
		return "Bow";
	}

	@Override
	public String getAttackTypeName() {
		return ("([1] Single Shoot [2] Double Shoot");
	}
	
}