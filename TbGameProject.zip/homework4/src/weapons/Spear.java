package weapons;

import opponents.Opponent;

public class Spear extends Weapon{

	
	public int firstAttack(int attack) {
		int combinedDamage = attack + getAdditionalAttack();
		int totalDamage = (int)Math.round(combinedDamage * 1.1);
		return totalDamage;
	}
	
	public int secondAttack(int attack) {
		int combinedDamage = attack + getAdditionalAttack();
		int totalDamage = (int)Math.round(combinedDamage * 2);
		return totalDamage;
	}
	public String toString() {
		return "Spear";
	}

	@Override
	public String getAttackTypeName() {
		return ("([1] Stab [2] thrown)");
	}
}