package weapons;
import opponents.Opponent;

public abstract class Weapon {

	private int additionalAttack;
	
	public Weapon() {
		// gives values between (10, 20)
		this.additionalAttack = ((int)Math.round(Math.random()*10))+10;
	}
	
	public int getAdditionalAttack() {
		return additionalAttack;
	}
	public abstract int firstAttack(int attack);
	public abstract int secondAttack(int attack);
	public abstract String getAttackTypeName();

}
